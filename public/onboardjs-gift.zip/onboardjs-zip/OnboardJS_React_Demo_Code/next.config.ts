import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  pageExtensions: ["js", "jsx", "md", "ts", "tsx"],
  // This is required to rewrite the PostHog API requests to the specific path set up in `instrumentation-client.ts`
  async rewrites() {
    return [
      {
        source: "/buda/static/:path*",
        // If your PostHog host is different from the EU host, change the destination URL accordingly.
        destination: "https://eu-assets.i.posthog.com/static/:path*",
      },
      {
        source: "/buda/:path*",
        // If your PostHog host is different from the EU host, change the destination URL accordingly.
        destination: "https://eu.i.posthog.com/:path*",
      },
      {
        source: "/buda/decide",
        // If your PostHog host is different from the EU host, change the destination URL accordingly.
        destination: "https://eu.i.posthog.com/decide",
      },
    ];
  },
  // This is required to support PostHog trailing slash API requests
  skipTrailingSlashRedirect: true,
};

export default nextConfig;
