/**
 * This file is used to initialize PostHog for client-side instrumentation.
 * It sets up the PostHog client with the necessary configuration.
 * 
 * This allows every import posthog from 'posthog-js' to use the initialized instance.
 */

import posthog from 'posthog-js'

posthog.init(process.env.NEXT_PUBLIC_POSTHOG_KEY!, {
  // The host for the PostHog API. Something obscure is recommended to avoid adblockers.
  api_host: '/buda',
  // The host for your PostHog. Either EU or US or your self-hosted instance.
  ui_host: 'https://eu.posthog.com',
  capture_pageview: true,
  defaults: '2025-05-24',
})
