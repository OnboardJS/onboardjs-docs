import { z } from "zod";

// This schema is used to validate input from client.
export const addEmailSchema = z.object({
  email: z.string(),
  firstName: z.string().optional(),
  lastName: z.string().optional(),
});

export const addEmailStrictSchema = z.object({
  email: z.string().email(),
  firstName: z.string().min(2).max(100),
  lastName: z.string().min(2).max(100),
});
