"use server";

import WelcomeEmail from "@/lib/resend/emails/welcome-email";
import { generateEmailId, resend } from "@/lib/resend/resend";
import { actionClient } from "../clients/action-client";
import { addEmailSchema } from "./schema";

export const addEmailAction = actionClient
  .inputSchema(addEmailSchema)
  .action(async ({ parsedInput }) => {
    const { email, firstName, lastName } = parsedInput;

    if (process.env.RESEND_AUDIENCE_ID) {
      // Add the email to the Resend Audience
      // This will create a new contact if it doesn't exist
      await resend.contacts.create({
        email,
        firstName,
        lastName,
        unsubscribed: false,
        audienceId: process.env.RESEND_AUDIENCE_ID,
      });
    }

    const emailId = generateEmailId();

    // Send the welcome email to the user
    return resend.emails.send({
      from: "Soma from OnboardJS <soma@onboardjs.com>",
      to: email,
      subject: "Your OnboardJS Demo & Example Code!",
      react: (
        <WelcomeEmail firstName={firstName} lastName={lastName} email={email} />
      ),
      headers: {
        "Idempotency-Key": emailId, // To prevent duplicate emails
        "X-Entity-Ref-ID": emailId, // To prevent threadding in Gmail
      },
    });
  });
