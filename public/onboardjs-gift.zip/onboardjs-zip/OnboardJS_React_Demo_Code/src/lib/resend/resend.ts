import { delay, nanoid } from '@/utils/utils'
import {
  type CreateEmailOptions,
  type CreateEmailRequestOptions,
  Resend,
} from 'resend'

export const generateEmailId = () => nanoid(11)

export const resend = new Resend(process.env.RESEND_API_KEY!)

/**
 * Resend only accepts 2 emails every second. This function will send emails
 * in batches of 2 every second.
 */
export async function sendRateLimitedEmails(
  createEmailOptions: {
    payload: CreateEmailOptions
    options?: CreateEmailRequestOptions
  }[],
): Promise<void> {
  for (let i = 0; i < createEmailOptions.length; i += 2) {
    await Promise.allSettled(
      createEmailOptions
        .slice(i, i + 2)
        .map((createEmailOption) =>
          resend.emails.send(
            createEmailOption.payload,
            createEmailOption.options,
          ),
        ),
    )

    // Sleep for 1 second to respect the rate limit.
    await delay(2000)
  }
}
