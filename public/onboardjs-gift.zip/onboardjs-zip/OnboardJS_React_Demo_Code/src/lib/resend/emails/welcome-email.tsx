import {
  Body,
  Button,
  Container,
  Head,
  Hr,
  Html,
  Img,
  Link,
  Preview,
  Section,
  Text,
} from '@react-email/components'

const baseUrl = 'https://onboardjs.com' // Base URL for images and links

export interface WelcomeEmailProps {
  firstName?: string;
  lastName?: string;
  email: string;
}

export const WelcomeEmail = ({ firstName }: WelcomeEmailProps) => (
  <Html>
    <Head />
    <Body style={main}>
      <Preview>
        Here’s the demo code + a little extra to boost your onboarding!
      </Preview>
      <Container style={container}>
        <Section style={box}>
          <Img
            src={`${baseUrl}/onboardjs-text-black.png`}
            width="auto"
            height="32"
            alt="OnboardJS"
          />
          <Hr style={hr} />
          <Text style={paragraph}>Hi {firstName ?? "Explorer"},</Text>
          <Text style={paragraph}>
            Thanks for taking the time to explore OnboardJS! We’re excited
            you’re interested in creating exceptional onboarding experiences.
          </Text>
          <Text style={paragraph}>
            As promised, here’s your link to the complete code for the demo you
            just experienced:
          </Text>
          <Button style={button} href={`https://onboardjs.com/gift`}>
            Download Your Demo Example Here
          </Button>
          <Hr style={hr} />
          <Text style={paragraph}>
            This example is a solid foundation, showing you how OnboardJS
            streamlines custom, engaging onboarding flows. Use it to jumpstart
            your next project – whether you’re building fresh or optimizing
            existing user journeys.
          </Text>
          <Text style={paragraph}>
            We’ll send occasional tips and updates to help you create truly
            impactful user experiences.
          </Text>
          <Text style={paragraph}>
            <strong>P.S.:</strong> Now that you’re onboard with OnboardJS, get
            ready to confidently get more of your customers onboard your product
            ship! All aboard for growth! 🚢
          </Text>
          <Text style={paragraph}>
            <strong>P.P.S.:</strong> Want to dive deeper? Check out our latest
            blog post on{" "}
            <Link
              style={anchor}
              href="https://onboardjs.com/blog/creating-aha-moments"
            >
              &ldquo;Creating ’Aha Moments’ in User Onboarding: A Developer’s
              Guide to Better First Impressions&rdquo; here.
            </Link>
          </Text>
          <Text style={paragraph}>— Soma from OnboardJS</Text>
          <Hr style={hr} />
          <Text style={footer}>OnboardJS</Text>
        </Section>
      </Container>
    </Body>
  </Html>
);

export default WelcomeEmail

WelcomeEmail.PreviewProps = {
  email: 'user@example.com',
  firstName: 'John',
  lastName: 'Doe',
}

const main = {
  backgroundColor: '#f6f9fc',
  fontFamily:
    '-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Ubuntu,sans-serif',
}

const container = {
  backgroundColor: '#ffffff',
  margin: '0 auto',
  padding: '20px 0 48px',
  marginBottom: '64px',
}

const box = {
  padding: '0 48px',
}

const hr = {
  borderColor: '#e6ebf1',
  margin: '20px 0',
}

const paragraph = {
  color: '#525f7f',

  fontSize: '16px',
  lineHeight: '24px',
  textAlign: 'left' as const,
}

const anchor = {
  color: '#2563eb',
}

const button = {
  backgroundColor: '#3b82f6',
  borderRadius: '5px',
  color: '#fff',
  fontSize: '16px',
  fontWeight: 'bold',
  textDecoration: 'none',
  textAlign: 'center' as const,
  display: 'block',
  padding: '10px',
}

const footer = {
  color: '#8898aa',
  fontSize: '12px',
  lineHeight: '16px',
}
