'use client'

import { createPostHogPlugin } from '@onboardjs/posthog-plugin'
import { OnboardingProvider } from '@onboardjs/react'
import posthog from 'posthog-js'
import OnboardingUI from './onboarding-ui'
import { stepRegistry } from './step-registry'
import { steps } from './steps'

export default function OnboardingLayout() {

  // Initialize the PostHog Plugin with the PostHog instance configured in `instrumentation-client.ts`
  // This allows the onboarding flow to track events with PostHog.
  const posthogPlugin = createPostHogPlugin({
    // Provide the PostHog instance to the plugin
    // This instance should be initialized in `instrumentation-client.ts`
    posthogInstance: posthog,
    // Prefix events with a specific prefix to avoid conflicts with other events
    eventPrefix: 'landing_page',
  })

  return (
    <OnboardingProvider
      steps={steps}
      componentRegistry={stepRegistry}
      plugins={[posthogPlugin]} // Add the PostHog plugin to the onboarding provider. Comment this line if you don't want to use PostHog.
      // Uncomment the following lines to enable localStorage persistence
      // localStoragePersistence={{
      //   key: 'onboarding-flow',
      //   ttl: 1000 * 60 * 60 * 24, // 1 day
      // }}

      // You can specify an initial context for the onboarding flow.
      // This context can be used to pre-fill data or set initial values for the onboarding steps
      initialContext={{ flowData: { onboardingType: 'developer' } }}>
      <OnboardingUI />
    </OnboardingProvider>
  )
}
