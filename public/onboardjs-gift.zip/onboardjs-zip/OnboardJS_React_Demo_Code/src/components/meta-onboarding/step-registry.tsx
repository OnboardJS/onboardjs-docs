import type { StepComponentProps } from '@onboardjs/react'
import dynamic from 'next/dynamic'
import type { ComponentType } from 'react'

// Preloading components for better video performance
import DevShowcase from './steps/dev-path/dev-showcase'

// Lazy loading components to reduce initial bundle size
const InitialStep: ComponentType<StepComponentProps> = dynamic(
  async () => import('./steps/initial-step'),
)
const EndStep: ComponentType<StepComponentProps> = dynamic(
  async () => import('./steps/end-step'),
)

const DevImpl: ComponentType<StepComponentProps> = dynamic(
  async () => import('./steps/dev-path/dev-impl'),
)

const DevTypeSelector: ComponentType<StepComponentProps> = dynamic(
  async () => import('./steps/dev-path/dev-type'),
)

const BusinessWelcome: ComponentType<StepComponentProps> = dynamic(
  async () => import('./steps/business-path/business-welcome'),
)

const BusinessWithOnboardJS: ComponentType<StepComponentProps> = dynamic(
  async () => import('./steps/business-path/business-onboardjs'),
)

const BusinessStep3: ComponentType<StepComponentProps> = dynamic(
  async () => import('./steps/business-path/business-3'),
)

// Registering all the Step Components for the specified step IDs in `step.ts`
export const stepRegistry = {
  initial: InitialStep,
  'dev-showcase': DevShowcase,
  'dev-impl': DevImpl,
  'dev-type': DevTypeSelector,
  'business-welcome': BusinessWelcome,
  'business-onboardjs': BusinessWithOnboardJS,
  'business-step-3': BusinessStep3,

  // You can reuse the EndStep for both developer and business paths by providing different props
  // in the step.ts 'business-end' and 'dev-end' steps.
  'dev-end': EndStep,
  'business-end': EndStep,
}
