'use client'

import { useOnboarding } from '@onboardjs/react'
import clsx from 'clsx'
import ThankYou from './thank-you'
import { Link } from '../link'
import { Logo } from '../logo'

const LogoComposition = (
  <Link
    href="/"
    aria-label="Home page"
    className="flex items-center gap-x-2 text-zinc-950"
  >
    <Logo className="size-4" />
    <span className="text-sm font-semibold">OnboardJS</span>
  </Link>
)

export default function OnboardingUI() {
  const { renderStep, currentStep, engine, state } = useOnboarding()

  if (!state) {
    // If the state is not initialized, show a loading state
    // This can happen if the onboarding engine is still initializing
    return (
      <div className="flex h-full w-full min-w-sm flex-col justify-center rounded-lg bg-white px-4">
        <div
          role="status"
          className="w-full animate-pulse space-y-4 py-8 sm:space-y-8"
        >
          <div className="flex max-w-full items-center justify-center gap-x-4 overflow-hidden">
            <div className="h-2 w-full rounded-full bg-gray-300"></div>
            <div className="h-2 w-full rounded-full bg-gray-200"></div>
            <div className="h-2 w-full rounded-full bg-gray-200"></div>
          </div>

          <div className="w-full rounded-lg border border-gray-200 p-4 py-6">
            <div className="mb-2.5 h-3 w-24 rounded-full bg-gray-300"></div>
            <div className="h-3 w-[80%] rounded-full bg-gray-200"></div>
          </div>

          <div className="w-full rounded-lg border border-gray-200 p-4 py-6">
            <div className="mb-2.5 h-3 w-24 rounded-full bg-gray-300"></div>
            <div className="h-3 w-[80%] rounded-full bg-gray-200"></div>
          </div>

          <div className="w-full rounded-lg border border-gray-200 p-4 py-6">
            <div className="mb-2.5 h-3 w-24 rounded-full bg-gray-300"></div>
            <div className="h-3 w-[80%] rounded-full bg-gray-200"></div>
          </div>
        </div>
        <div className="grow"></div>
        <div className="ml-auto pb-2">{LogoComposition}</div>
      </div>
    )
  }

  if (state.isCompleted || !currentStep) {
    // If the onboarding process is completed or there is no current step anymore,
    // render the Thank You component
    return <ThankYou />
  }

  return (
    <div className="sm:min-w-sm divide-y divide-gray-200 overflow-hidden rounded-lg bg-white text-zinc-950 shadow-sm xl:max-w-none xl:min-w-xl">
      <div className="px-4 py-6 sm:p-6">
        <div className="mb-6 sm:mb-8">
          <div className="flex w-full items-center gap-x-2">
            {/* This is the progress tracker. */}
            {engine?.getRelevantSteps()?.map((_, index) => (
              <span
                key={index}
                className={clsx(
                  'h-2 w-full rounded-full transition-colors duration-200',
                  index < state.currentStepNumber
                    ? 'bg-blue-600'
                    : 'bg-gray-300',
                )}
              ></span>
            ))}
          </div>
        </div>
        {/* Render the title and subtitle of the current step, if defined in the step.meta (steps.ts) */}
        {currentStep?.meta?.title && (
          <h2 className="mt-4 text-lg leading-6 font-medium text-gray-900">
            {currentStep.meta.title}
          </h2>
        )}
        {currentStep?.meta?.subtitle && (
          <p className="mt-1 max-w-md text-sm text-gray-500">
            {currentStep.meta.subtitle}
          </p>
        )}
        {/* Render the current step of the onboarding process */}
        <div className="my-4 mb-6 sm:my-8">{renderStep()}</div>
        {/* Bottom OnboardJS Logo for branding */}
        <div className="ml-auto w-min">{LogoComposition}</div>
      </div>
    </div>
  )
}
