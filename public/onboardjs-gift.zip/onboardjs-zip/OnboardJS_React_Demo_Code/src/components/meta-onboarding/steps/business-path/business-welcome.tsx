'use client'

import { useOnboarding } from '@onboardjs/react'
import ChurnIncreaseChart from './churn-increase-chart'

export default function BusinessWelcome() {
  const { next, previous } = useOnboarding()
  return (
    <>
      <ChurnIncreaseChart className='my-4' />
      
      <div className="mt-6 flex w-full justify-end">
        <button
          onClick={() => previous()}
          className="mr-2 rounded-md bg-gray-200 px-4 py-2 text-gray-700 disabled:cursor-not-allowed disabled:bg-gray-300"
        >
          Back
        </button>
        <button
          onClick={() => next()}
          className="rounded-md bg-blue-600 px-4 py-2 text-white disabled:cursor-not-allowed disabled:bg-gray-300"
        >
          Continue
        </button>
      </div>
    </>
  )
}
