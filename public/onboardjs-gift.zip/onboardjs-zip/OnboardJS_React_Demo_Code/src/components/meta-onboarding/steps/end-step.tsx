"use client";

import { addEmailAction } from "@/actions/add-email/add-email";
import { addEmailStrictSchema } from "@/actions/add-email/schema";
import { ErrorMessage, Field, Label } from "@/components/fieldset";
import { Input } from "@/input";
import { zodResolver } from "@hookform/resolvers/zod";
import { useOnboarding, type StepComponentProps } from "@onboardjs/react";
import { useAction } from "next-safe-action/hooks";
import { useForm } from "react-hook-form";

export default function EndStep({ coreContext }: StepComponentProps) {
  const { currentStep, next } = useOnboarding();
  const {
    register,
    handleSubmit,
    formState: { errors, isValid },
  } = useForm({
    resolver: zodResolver(addEmailStrictSchema),
  });

  const addEmail = useAction(addEmailAction);

  const onSubmit = handleSubmit((data) => {
    console.log("Form submitted:", data);
    addEmail.execute({
      email: data.email,
      firstName: data.firstName,
      lastName: data.lastName,
    });

    // Finishing the onboarding flow
    next();
  });

  return (
    <form className="animate-fade text-zinc-950" onSubmit={onSubmit}>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field>
          <Label>First Name</Label>
          <Input
            placeholder="John"
            {...register("firstName", {
              required: {
                value: true,
                message: "First name is required",
              },
            })}
          />
          <ErrorMessage>{errors.firstName?.message}</ErrorMessage>
        </Field>
        <Field>
          <Label>Last Name</Label>
          <Input
            placeholder="Doe"
            {...register("lastName", {
              required: {
                value: true,
                message: "Last name is required",
              },
            })}
          />
          <ErrorMessage>{errors.lastName?.message}</ErrorMessage>
        </Field>
      </div>
      <Field className="mt-4">
        <Label>Email</Label>
        <Input
          type="email"
          autoComplete="email"
          autoCapitalize="off"
          autoCorrect="off"
          spellCheck="false"
          placeholder="jane@company.com"
          {...register("email", {
            required: {
              value: true,
              message: "Email is required",
            },
          })}
        />
        <ErrorMessage>{errors.email?.message}</ErrorMessage>
      </Field>

      <p className="my-6 mr-4 max-w-sm text-xs text-zinc-500">
        {coreContext?.flowData?.onboardingType === "business-rep"
          ? "We’ll also send occasional updates and insights to help you grow your user base."
          : "We’ll also send occasional updates and insights to help you build better onboarding experiences."}
      </p>
      <div className="flex w-full justify-end">
        <button
          type="submit"
          disabled={!isValid}
          className="rounded-md bg-blue-600 px-4 py-2 text-white disabled:cursor-not-allowed disabled:bg-gray-300"
        >
          {currentStep?.meta?.cta ?? "Send Me the Code!"}
        </button>
      </div>
    </form>
  );
}
