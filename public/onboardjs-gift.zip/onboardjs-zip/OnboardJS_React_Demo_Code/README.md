The is the OnboardJS Gift project. It is a simple Next.js application that showcases the OnboardJS onboarding framework. The project includes a layout and a page that uses the OnboardingLayout component to render the onboarding UI.

# Project Structure
- `src/app/page.tsx`: The main page of the application that renders the OnboardingLayout component.
- `src/app/layout.tsx`: The root layout of the application that defines the metadata and layout structure.
- `src/components/meta-onboarding/onboarding-ui.tsx`: The component that handles the onboarding UI, including rendering steps, progress tracking, and completion state.
- `src/components/meta-onboarding/onboarding-layout.tsx`: The layout component that wraps the onboarding UI and provides the necessary context for the onboarding process.
- `src/components/meta-onboarding/steps.ts`: The file that defines the steps of the onboarding process.
- `src/components/meta-onboarding/step-registry.tsx`: The file that registers the step components for the onboarding process.

# Getting Started
1. Copy the project files to your local machine.
2. Install the necessary dependencies by running `npm install`.
3. Start the development server with `npm run dev`.
4. Open your browser and navigate to `http://localhost:3000` to see the onboarding UI in action.

# Features
- **PostHog Integration**: The onboarding process is integrated with PostHog for analytics and tracking user interactions.
- **Resend Welcome Email**: The onboarding process includes a step to send the welcome email to the user.
- **Onboarding Steps**: The onboarding process consists of multiple steps, each with its own UI and logic.

# Configuration
- The project uses environment variables for configuration. Make sure to set up your `.env` file from the `.example.env` file.

# Dependencies
This project is meant to represent a full-fledged production Next.js application embedding the OnboardJS onboarding flow. Therefore, it includes a variety of dependencies that are commonly used in Next.js applications. Here is a list of the main dependencies:

- `next`: The Next.js framework for building the application.
- `react`: The React library for building user interfaces.
- `posthog-js`: The PostHog library for analytics and tracking.
- `recharts`: The Recharts library for some graphs and charts.
- `@onboardjs/core`: The core library for the OnboardJS onboarding framework.
- `@onboardjs/react`: The React bindings for the OnboardJS onboarding framework.
- `@onboardjs/posthog`: The PostHog plugin for the OnboardJS onboarding framework.
- `resend`: The Resend library for sending emails.
- `next-safe-action`: A library for safely handling actions in Next.js applications.
- `@headlessui/react`: A library for building accessible UI components in React.
- `prism-react-renderer`: A library for syntax highlighting in React applications.
- `lucide-react`: A library for using Lucide icons in React applications.
- `react-hook-form`: A library for managing forms in React applications.
- `zod`: A library for schema validation in JavaScript applications.
- `react-email`: A library for building and sending emails in React applications.
